﻿using System;

namespace Randomszam_kitalalo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program generál egy egész számot 1-100ig és ki kell taláni, hogy melyik számra gondolt");

            Random rnd = new Random();
            int num = rnd.Next(1, 101);
            int tip;
            int tippszam = 0;
            int szam = -1; 
            bool szam1 = false; 

            do
            {
                Console.WriteLine("Tippeld meg a számot");
                tip = Convert.ToInt32(Console.ReadLine());
                tippszam++;

                if (tip < num)
                {
                    Console.WriteLine("A szám nagyobb");
                    if (tip >= 100)
                    {
                        Console.WriteLine("Ne írj butaságot! A számnak 1 és 100 között kell lennie.");
                    }
                    else if (szam1 && szam != -1)
                    {
                        Console.WriteLine("Ne légy buta! Próbálkozz magasabb számmal.");
                    }
                    szam1 = true;
                }
                else if (tip > num)
                {
                    Console.WriteLine("A szám kisebb");
                    if (tip >= 100)
                    {
                        Console.WriteLine("Ne írj butaságot! A számnak 1 és 100 között kell lennie.");
                    }
                    else if (!szam1 && szam != -1)
                    {
                        Console.WriteLine("Ne légy buta! Próbálkozz alacsonyabb számmal.");
                    }
                    szam1 = false;
                }
                else
                {
                    Console.WriteLine("Eltaláltad a számot gratulálok");
                    Console.WriteLine($"Tippek száma: {tippszam}");
                }

                szam = tip; 

            } while (tip != num);

            Console.ReadLine();



        }
    }
}
