﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2fokuegyenlet
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program a másodfokú egyenletet számolja ki");
            Console.WriteLine("Az általános alakja ax^2 + bx + c = 0");

            Console.WriteLine("Kérem adja meg az első együtthatót (a) számot: ");
            double elsoegyutthato = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Kérem a második együtthatót (b) számot: ");
            double masodikegyutthato = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Kérem a harmadik együtthatót (c) számot: ");
            double harmadiegyutthato = Convert.ToDouble(Console.ReadLine());


            double diszkriminans = masodikegyutthato * masodikegyutthato - 4 * elsoegyutthato * harmadiegyutthato;

            if (diszkriminans >= 0)
            {
                double gyok = Math.Sqrt(diszkriminans);
                double osztas = 2 * elsoegyutthato;
                double elsomegoldas = (-masodikegyutthato + gyok) / osztas;
                double masodikmegoldas = (-masodikegyutthato - gyok) / osztas;
                Console.WriteLine("Az első eredmény: {0:0.00}", elsomegoldas);
                Console.WriteLine("A második eredmény: {0:0.00}", masodikmegoldas);
            }
            else
            {
                Console.WriteLine("Nincs valós gyöke az egyenletnek.");
            }

            Console.ReadLine();

        }
    }
}
