﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace feladatosora_2023
{
    internal class Program
    {
        static void Main()
        {
            Console.Write("Hány alkalommal legyen feldobás? ");
            int N = Convert.ToInt32(Console.ReadLine());

            int anniWins = 0;
            int panniWins = 0;

            Random random = new Random();

            for (int i = 0; i < N; i++)
            {
                int kocka1 = random.Next(1, 7);
                int kocka2 = random.Next(1, 7);
                int kocka3 = random.Next(1, 7);

                int osszeg = kocka1 + kocka2 + kocka3;

                Console.Write($"Dobás: {kocka1} + {kocka2} + {kocka3} = {osszeg}    Nyert: ");

                if (osszeg < 10)
                {
                    Console.WriteLine("Anni");
                    anniWins++;
                }
                else
                {
                    Console.WriteLine("Panni");
                    panniWins++;
                }
            }

            Console.WriteLine($"A játék során {anniWins} alkalommal Anni, {panniWins} alkalommal Panni nyert.");
            Console.ReadKey();
        }
        
    }
}

