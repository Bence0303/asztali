﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista_feladat
{
    class Program
    {
        static void Main()
        {
            bool folytatni = true;

            while (folytatni)
            {
                List<int> szamok = new List<int>();
                int sorszam = 1;

                Console.WriteLine("Adjon meg pozitív egész számokat (0 végjegyig)!");
                while (true)
                {
                    Console.Write($"Adja meg a(z) {sorszam}. számot: ");
                    if (int.TryParse(Console.ReadLine(), out int szam) && szam >= 0)
                    {
                        szamok.Add(szam);
                        sorszam++;
                    }
                    else
                    {
                        Console.WriteLine("Ne légy buta. Kérjük, adjon meg egy pozitív egész számot vagy 0-t!");
                    }

                    if (szam == 0)
                    {
                        break;
                    }
                }

                Console.WriteLine("Bevitt számok:");
                for (int i = 0; i < szamok.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. szám: {szamok[i]}");
                }

                Console.WriteLine("Szeretnéd folytatni? (igen/nem)");
                string valasz = Console.ReadLine();
                if (valasz.ToLower() != "igen")
                {
                    Console.WriteLine("Csumi!");
                    folytatni = false;
                }
            }

            Console.ReadLine();
        }
    }
}