﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tomb
{

    class Program
    {
        static void Main()
        {
            string[] nevek = { "Géza", "gabi", "pista", "emma", "fanni", "judit", "levi", "bence", "martin", "máté" };
            double[] jegyek = new double[nevek.Length];
            double jegyekOsszeg = 0;
            Random random = new Random();

            for (int i = 0; i < nevek.Length; i++)
            {
                double randomJegy = random.NextDouble() * 5 + 1;
                jegyek[i] = randomJegy;
                jegyekOsszeg += randomJegy;
            }

            double atlag = jegyekOsszeg / nevek.Length;

            Console.WriteLine("Az átlagjegy: " + atlag);
            Console.WriteLine("A jobb jegyekkel rendelkező diákok:");
            for (int i = 0; i < nevek.Length; i++)
            {
                if (jegyek[i] > atlag)
                {
                    Console.WriteLine(nevek[i]);
                }
            }
            Console.ReadLine();
        }
    }
}
