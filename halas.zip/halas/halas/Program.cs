﻿using System;

namespace Halas
{
    class Program
    {
        static void Main()
        {
            string[] nevek = new string[14];
            double[] hosszak = new double[14];
            double[] sulyok = new double[14];

            Random random = new Random();

            for (int i = 0; i < nevek.Length; i++)
            {
                nevek[i] = "Hal" + (i + 1);
                hosszak[i] = random.Next(10, 71);
                sulyok[i] = random.NextDouble() * 5.0; 
            }

            double atlagHossz = 0;
            double osszSuly = 0;

            for (int i = 0; i < nevek.Length; i++)
            {
                atlagHossz += hosszak[i];
                osszSuly += sulyok[i];
            }

            atlagHossz /= nevek.Length;
            Console.WriteLine($"Az átlag hossz: {atlagHossz} cm");
            Console.WriteLine($"Az összsúly: {osszSuly} kg");

            Console.WriteLine("Az 70 dkg-nál nagyobb halak:");
            for (int i = 0; i < nevek.Length; i++)
            {
                if (sulyok[i] > 0.70)
                {
                    Console.WriteLine($"{nevek[i]} - Súly: {sulyok[i]} kg");
                }
            }

            int kisebbHalakSzama = 0;
            for (int i = 0; i < nevek.Length; i++)
            {
                if (sulyok[i] > 0.50 && hosszak[i] < 28)
                {
                    kisebbHalakSzama++;
                }
            }
            Console.WriteLine($"A 50 dkg-nál nagyobb és 28 cm-nél kisebb halak száma: {kisebbHalakSzama}");

            bool vanNagyHal = false;
            for (int i = 0; i < nevek.Length; i++)
            {
                if (sulyok[i] > 2)
                {
                    vanNagyHal = true;
                    break;
                }
            }

            if (vanNagyHal)
            {
                Console.WriteLine("Van 2 kg-nál nagyobb hal.");
            }
            else
            {
                Console.WriteLine("Nincs 2 kg-nál nagyobb hal.");
            }

            bool van40dkghal = false;
            for (int i = 0; i < nevek.Length; i++)
            {
                if (sulyok[i] > 0.4)
                {
                    van40dkghal = true;
                    break;
                }
            }

            if (van40dkghal)
            {
                Console.WriteLine("Van 40dkg-nál kisebb hal");
            }
            else
            {
                Console.WriteLine("Nincs 40dkg-nál kisebb hal");
            }

            double legkisebbsuly = sulyok[0];
            foreach (double suly in sulyok)
            {
                if (suly < legkisebbsuly)
                {
                    legkisebbsuly = suly;
                }
            }
            Console.WriteLine("A legkisebb súly: " + legkisebbsuly.ToString() + " kg");

            Console.ReadLine();
        }
    }
}
