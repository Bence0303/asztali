﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hazifeladat
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Kérem adja meg a számokat ami a tömbe lesz : ");
            int n = int.Parse(Console.ReadLine());

            int[] tomb = new int[n];

            for (int i = 0; i < n; i++)
            {
                Console.Write($"Kérem adja meg a {i + 1}. számot: ");
                tomb[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("Kérem adja meg a keresett számot: ");
            int keresettSzam = int.Parse(Console.ReadLine());

            int szamlalo = 0;

            for (int i = 0; i < n; i++)
            {
                if (tomb[i] == keresettSzam)
                {
                    szamlalo++;
                }
            }

            Console.WriteLine($"A {keresettSzam} szám {szamlalo} alkalommal szerepel a tömbben.");
            Console.ReadLine();
        }
    }

}

