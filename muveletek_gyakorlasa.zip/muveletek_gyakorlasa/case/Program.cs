﻿using System;

namespace @case
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool folytatni = true;

            while (folytatni)
            {
                Console.WriteLine("Ez a program két tetszőleges számmal elvégez négy alapműveletet");

                Console.WriteLine("Kérem az első számot: ");
                double elsoszam = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Kérem a második számot: ");
                double masodikszam = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Milyen műveletet végezzen el a program: (+, -, /, *) ");
                string egyenlet = Console.ReadLine();

                double eredmeny = 0;

                switch (egyenlet)
                {
                    case "+":
                        eredmeny = elsoszam + masodikszam;
                        Console.WriteLine("Az összeadás eredménye: " + eredmeny);
                        break;

                    case "-":
                        eredmeny = elsoszam - masodikszam;
                        Console.WriteLine("A kivonás eredménye: " + eredmeny);
                        break;

                    case "/":
                        eredmeny = elsoszam / masodikszam;
                        Console.WriteLine("Az osztás eredménye: " + eredmeny);
                        break;

                    case "*":
                        eredmeny = elsoszam * masodikszam;
                        Console.WriteLine("A szorzás eredménye: " + eredmeny);
                        break;

                    default:
                        Console.WriteLine("Érvénytelen művelet.");
                        break;
                }

                Console.WriteLine("Szeretne még egy számot számolni? (igen/nem)");
                string valasz = Console.ReadLine();

                if (valasz.ToLower() != "igen")
                {
                    Console.WriteLine("Viszontlátás!");
                    folytatni = false;
                }
            }
            Console.ReadKey();
        }
    }
}
